#ifndef INTERFACE_H
#define INTERFACE_H

int nb_sommet();
int est_adjacent(int u, int v);

#endif
